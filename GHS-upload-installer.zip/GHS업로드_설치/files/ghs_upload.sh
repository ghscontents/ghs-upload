#!/bin/bash
# GHS 업로드: 선택한 Final Cut 라이브러리(.fcpbundle)를 압축해
# GHS 서버의 릴 사운드 라이브러리 폴더에 "번호_제목.zip"으로 올린다.
#
# 번호 규칙: 라이브러리 이름이 "숫자_"로 시작하면 그 번호를 그대로 쓰고,
#           아니면 서버의 마지막 번호 + 1을 붙인다.
# 안전장치: 같은 번호의 파일이 서버에 있으면 덮어쓰지 않고 멈춘다.
#           Final Cut에서 라이브러리가 열려 있으면 멈춘다.
#
# 사용법: ghs_upload.sh <라이브러리.fcpbundle> [...]
#        DRY_RUN=1 ghs_upload.sh ...   (압축·검증만 하고 서버에 올리지 않음)

export PATH="/usr/bin:/bin:/usr/sbin:/sbin"
VOLUME="/Volumes/1_GHS"
LOG="$HOME/Library/Logs/GHS업로드.log"
TITLE="GHS 업로드"

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; echo "$*"; }
notify() {
  osascript -e 'on run argv' -e 'display notification (item 2 of argv) with title (item 1 of argv)' -e 'end run' "$TITLE" "$1" >/dev/null 2>&1
}
fail() { log "❌ $1"; notify "❌ $1"; }

if [ $# -eq 0 ]; then
  echo "사용법: $0 <라이브러리.fcpbundle> [...]"; exit 1
fi

# --- 서버 폴더 찾기 (한글 이름 인코딩 차이 때문에 find로 찾는다) ---
if ! mount | grep -q " on $VOLUME "; then
  fail "서버(1_GHS)가 연결돼 있지 않아요. Finder에서 ⌘K → smb://GHS 로 연결해 주세요."
  exit 1
fi
DEST=""
while IFS= read -r d; do
  if [ -n "$DEST" ]; then fail "업로드 폴더 후보가 여러 개예요. 확인이 필요해요."; exit 1; fi
  DEST="$d"
done < <(find "$VOLUME" -maxdepth 3 -type d -path "$VOLUME/13_*/01_GHS_*/01_*" 2>/dev/null)
if [ -z "$DEST" ]; then
  fail "서버에서 '01_릴_사운드_라이브러리' 폴더를 찾지 못했어요."
  exit 1
fi

# 서버 파일 목록 (서버는 한글을 자모 분리형으로 돌려줘서 일반 형태로 바꾼다)
server_list() { ls "$DEST" | iconv -f UTF-8-MAC -t UTF-8 2>/dev/null; }
# 일반 형태 이름 → 서버에 실제로 있는 이름
server_real_name() {
  local want="$1" f
  while IFS= read -r f; do
    [ "$(printf '%s' "$f" | iconv -f UTF-8-MAC -t UTF-8)" = "$want" ] && { printf '%s' "$f"; return 0; }
  done < <(ls "$DEST")
  return 1
}

last_number() {
  server_list | sed -n 's/^\([0-9][0-9]*\)_.*\.zip$/\1/p' | sed 's/^0*//' | sort -n | tail -1
}

# 덮어쓰기 확인 창. CONFIRM_REPLACE=1이면 창 없이 진행 (채팅에서 이미 확인받은 경우)
confirm_replace() {
  [ "${CONFIRM_REPLACE:-0}" = "1" ] && return 0
  osascript -e 'on run argv' \
    -e 'display dialog (item 1 of argv) with title "GHS 업로드" buttons {"취소", "덮어쓰기"} default button "덮어쓰기" cancel button "취소" with icon caution' \
    -e 'end run' "$1" >/dev/null 2>&1
}

library_is_open() {
  local lib="$1"
  pgrep -x "Final Cut Pro" >/dev/null || return 1
  lsof -Fn -c "Final Cut Pro" 2>/dev/null | grep -qF "n$lib/"
}

status=0
for src in "$@"; do
  src="${src%/}"
  base="$(basename "$src")"
  case "$base" in
    *.fcpbundle) ;;
    *) fail "'$base'은(는) Final Cut 라이브러리가 아니라서 건너뛰어요."; status=1; continue ;;
  esac
  if [ ! -d "$src" ]; then fail "'$base'을(를) 찾을 수 없어요."; status=1; continue; fi
  src="$(cd "$(dirname "$src")" && pwd)/$base"
  name="$(printf '%s' "${base%.fcpbundle}" | iconv -f UTF-8-MAC -t UTF-8)"

  if library_is_open "$src"; then
    fail "'$name'이(가) Final Cut에서 열려 있어요. 라이브러리를 닫고 다시 해 주세요."
    status=1; continue
  fi

  # 번호 정하기: 이름의 번호 → 서버에 같은 제목이 있으면 그 번호 → 마지막 번호 + 1
  if [[ "$name" =~ ^([0-9]+)_(.+)$ ]]; then
    num="${BASH_REMATCH[1]}"
  else
    same_title="$(server_list | awk -v t="_${name}.zip" 'length($0)>length(t) && substr($0,length($0)-length(t)+1)==t && $0 ~ /^[0-9]+_/' | head -1)"
    if [ -n "$same_title" ]; then
      num="${same_title%%_*}"
    else
      last="$(last_number)"
      num=$(( ${last:-0} + 1 ))
    fi
    name="${num}_${name}"
  fi
  zipname="$name.zip"
  numre="^0*$(echo "$num" | sed 's/^0*//')_.*\.zip$"

  # 같은 번호가 이미 있으면 확인 후 덮어쓰기
  existing="$(server_list | grep -E "$numre" | head -1)"
  if [ -n "$existing" ]; then
    if [ "$existing" = "$zipname" ]; then
      msg="서버에 이미 '$existing'이(가) 있어요.

새 버전으로 덮어쓸까요? 기존 파일은 남지 않아요."
    else
      msg="서버에 같은 ${num}번 파일 '$existing'이(가) 있어요.

'$zipname'(으)로 덮어쓸까요? 기존 파일은 지워져요."
    fi
    if ! confirm_replace "$msg"; then
      log "⏹ 취소: $zipname (서버에 $existing 있음)"
      notify "⏹ $zipname 업로드를 취소했어요."
      continue
    fi
    log "↻ 덮어쓰기 승인: $existing → $zipname"
  fi

  notify "⏳ $zipname 압축 중…"
  log "▶ 시작: $src → $zipname"
  tmp="$(mktemp -d "${TMPDIR:-/tmp}/ghs_upload.XXXXXX")"
  if ! ditto -c -k --sequesterRsrc --keepParent "$src" "$tmp/$zipname" 2>>"$LOG"; then
    fail "'$name' 압축에 실패했어요."; rm -rf "$tmp"; status=1; continue
  fi
  if ! unzip -tqq "$tmp/$zipname" >/dev/null 2>>"$LOG"; then
    fail "'$zipname' 압축 파일 검사에 실패했어요."; rm -rf "$tmp"; status=1; continue
  fi
  size=$(stat -f %z "$tmp/$zipname")
  mb=$(( size / 1024 / 1024 ))

  if [ "${DRY_RUN:-0}" = "1" ]; then
    log "🧪 테스트 모드: $zipname (${mb}MB) 압축·검사 완료, 서버에는 올리지 않음 → $tmp/$zipname"
    notify "🧪 테스트: $zipname (${mb}MB) 준비 완료, 서버에는 안 올렸어요."
    continue
  fi

  notify "⏳ $zipname (${mb}MB) 서버로 올리는 중…"
  # 서버(SMB)는 한글 이름을 자모 분리형으로 써야 이름 바꾸기가 된다
  srvname="$(printf '%s' "$zipname" | iconv -f UTF-8 -t UTF-8-MAC)"
  partial="$DEST/.${srvname}.uploading"
  if ! cp "$tmp/$zipname" "$partial" 2>>"$LOG"; then
    fail "'$zipname' 서버 복사에 실패했어요."; rm -f "$partial"; rm -rf "$tmp"; status=1; continue
  fi
  if [ "$(stat -f %z "$partial" 2>/dev/null)" != "$size" ]; then
    fail "'$zipname' 서버에 올라간 크기가 달라요. 다시 시도해 주세요."; rm -f "$partial"; rm -rf "$tmp"; status=1; continue
  fi
  # 올리는 사이 승인받지 않은 같은 번호 파일이 생겼는지 다시 확인
  now="$(server_list | grep -E "$numre" | head -1)"
  if [ -n "$now" ] && [ "$now" != "$existing" ]; then
    fail "올리는 사이 서버에 ${num}번 파일 '$now'이(가) 생겼어요. 덮어쓰지 않고 멈췄어요."; rm -f "$partial"; rm -rf "$tmp"; status=1; continue
  fi
  # 승인받은 기존 파일 제거 (새 파일이 서버에 다 올라간 뒤에만)
  if [ -n "$existing" ]; then
    real="$(server_real_name "$existing")"
    if [ -z "$real" ] || ! rm -f "$DEST/$real"; then
      fail "기존 '$existing'을(를) 지우지 못했어요. 새 파일은 올리지 않았어요."; rm -f "$partial"; rm -rf "$tmp"; status=1; continue
    fi
  fi
  if ! mv -n "$partial" "$DEST/$srvname" 2>>"$LOG" || [ -e "$partial" ]; then
    fail "'$zipname' 이름 바꾸기에 실패했어요."; rm -f "$partial"; rm -rf "$tmp"; status=1; continue
  fi
  rm -rf "$tmp"
  log "✅ 완료: $zipname (${mb}MB)"
  notify "✅ $zipname (${mb}MB) 업로드 완료"
done
exit $status
