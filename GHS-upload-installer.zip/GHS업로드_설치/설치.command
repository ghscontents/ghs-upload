#!/bin/bash
# GHS 업로드 설치: 더블클릭하면 Finder 우클릭 메뉴 'GHS 업로드'가 설치돼요.
cd "$(dirname "$0")" || exit 1
SRC="$(pwd)/files"
APP="$HOME/Library/Application Support/GHS업로드"
SVC="$HOME/Library/Services"
echo "GHS 업로드를 설치할게요…"
if [ ! -f "$SRC/ghs_upload.sh" ] || [ ! -d "$SRC/GHS 업로드.workflow" ]; then
  echo "❌ 설치 파일이 없어요. zip을 다시 풀어서 폴더째로 실행해 주세요."; read -n1 -p "아무 키나 누르면 닫혀요"; exit 1
fi
mkdir -p "$APP" "$SVC"
cp "$SRC/ghs_upload.sh" "$APP/ghs_upload.sh" && chmod +x "$APP/ghs_upload.sh"
rm -rf "$SVC/GHS 업로드.workflow"
ditto "$SRC/GHS 업로드.workflow" "$SVC/GHS 업로드.workflow"
xattr -dr com.apple.quarantine "$APP" "$SVC/GHS 업로드.workflow" 2>/dev/null
/System/Library/CoreServices/pbs -flush >/dev/null 2>&1
killall Finder >/dev/null 2>&1
if [ -x "$APP/ghs_upload.sh" ] && [ -d "$SVC/GHS 업로드.workflow" ]; then
  echo ""
  echo "✅ 설치 완료!"
  echo "Finder에서 .fcpbundle 우클릭 → 빠른 동작 → GHS 업로드"
  echo "(메뉴가 안 보이면 빠른 동작 → 사용자화… 에서 'GHS 업로드' 체크)"
else
  echo "❌ 설치에 실패했어요. 담당자에게 이 창을 캡처해서 보내 주세요."
fi
echo ""
read -n1 -p "아무 키나 누르면 이 창이 닫혀요"
